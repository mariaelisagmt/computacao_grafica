var searchData=
[
  ['ambientreflection',['ambientReflection',['../classscene_1_1_object.html#a25c68d682b3620b0257f59db215ffe23',1,'scene::Object']]],
  ['ambientreflectionname',['ambientReflectionName',['../classscene_1_1_shaded_object.html#a7c49116b11a05b9a7eed925e83e27ee4',1,'scene::ShadedObject']]],
  ['applytransform',['applyTransform',['../classscene_1_1_object.html#a30b47bcd40234142c873a8ccef3d8d17',1,'scene::Object']]]
];
