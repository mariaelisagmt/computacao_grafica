var searchData=
[
  ['drawarrays',['drawArrays',['../classscene_1_1_shaded_object.html#a496b9a1a88487535951fa058d14265f8',1,'scene::ShadedObject::drawArrays()'],['../classshaderutils_1_1_shader_proxy.html#a02078fb32a3e408fd31c51388beb2e1c',1,'shaderutils::ShaderProxy::drawArrays()']]],
  ['drawelements',['drawElements',['../classscene_1_1_shaded_object.html#aadbd7f9e0b8575199125cd9c12faeab0',1,'scene::ShadedObject::drawElements()'],['../classshaderutils_1_1_shader_proxy.html#a3b2b201f82d2cbfb814b2d582a73c9e5',1,'shaderutils::ShaderProxy::drawElements()']]]
];
