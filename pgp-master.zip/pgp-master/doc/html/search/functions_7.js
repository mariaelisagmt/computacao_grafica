var searchData=
[
  ['translate',['translate',['../classscene_1_1_object.html#a8b633a7d024f1fd0102e260570e0fbab',1,'scene::Object::translate()'],['../classscene_1_1_camera.html#abcd0b4dc8f06f5af319d606f8a0571b8',1,'scene::Camera::translate()']]]
];
