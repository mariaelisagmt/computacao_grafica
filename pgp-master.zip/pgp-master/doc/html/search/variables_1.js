var searchData=
[
  ['data',['data',['../classscene_1_1_shaded_object.html#ad5127e62295e11f3ae4af42e2e517bff',1,'scene::ShadedObject']]],
  ['diffusereflection',['diffuseReflection',['../classscene_1_1_object.html#a4608ddd5375279ce31e1da48e9963759',1,'scene::Object']]],
  ['diffusereflectionname',['diffuseReflectionName',['../classscene_1_1_shaded_object.html#a71a51a5d138c364b956684a7e0394eac',1,'scene::ShadedObject']]]
];
