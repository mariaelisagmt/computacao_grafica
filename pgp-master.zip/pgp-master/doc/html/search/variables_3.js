var searchData=
[
  ['shader',['shader',['../classscene_1_1_shaded_object.html#a4a7b0d0844a6fd186fff1b58c97adbfe',1,'scene::ShadedObject::shader()'],['../classscene_1_1_camera.html#a114ec90a596436a0598685d877f6b9d6',1,'scene::Camera::shader()']]],
  ['shininess',['shininess',['../classscene_1_1_object.html#ad0d064fc3da95f59e0fea3a39122e9c5',1,'scene::Object']]],
  ['shininessname',['shininessName',['../classscene_1_1_shaded_object.html#a15626025c84615d9b67fb40a13496217',1,'scene::ShadedObject']]],
  ['specularreflection',['specularReflection',['../classscene_1_1_object.html#ae584bfd42e862d486b31567c3f996773',1,'scene::Object']]],
  ['specularreflectionname',['specularReflectionName',['../classscene_1_1_shaded_object.html#a957ab48c3aaa1474bac1903c19c54af8',1,'scene::ShadedObject']]]
];
