#version 120
varying vec4 corFinal;
void main(void){
	gl_FragColor = corFinal;
}
