#version 120
varying vec4 fcolor;
void main(void){
	gl_FragColor = fcolor;
}
