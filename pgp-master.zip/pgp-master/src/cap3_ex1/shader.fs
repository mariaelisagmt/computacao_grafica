#version 120
uniform vec4 uColor;
void main(void){
	gl_FragColor = uColor;
}
